import sys
print(sys.PATH)
x = 2
print(2 ** 8)